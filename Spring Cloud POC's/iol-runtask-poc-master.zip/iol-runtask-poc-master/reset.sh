cf d -f runner
cf ds -f scheduler-joshlong
cf delete-job -f my-job
