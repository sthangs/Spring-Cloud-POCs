cf job-schedules
cf jobs
cf job-history my-job
