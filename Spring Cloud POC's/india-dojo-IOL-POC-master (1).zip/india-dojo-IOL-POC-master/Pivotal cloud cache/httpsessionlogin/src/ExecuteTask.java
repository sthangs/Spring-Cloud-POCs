public class ExecuteTask {

	public String retmyString() {
		return "KPN";
		
	}
}
